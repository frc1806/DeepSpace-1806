var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "c", "globals_c.html", null ],
    [ "f", "globals_f.html", null ],
    [ "j", "globals_j.html", null ],
    [ "k", "globals_k.html", null ],
    [ "l", "globals_l.html", null ],
    [ "m", "globals_m.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ]
];