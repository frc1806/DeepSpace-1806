var searchData=
[
  ['valueupdated',['ValueUpdated',['../classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_motor_controller.html#a4712ba671d43070dd7d418504d506d84',1,'ctre::phoenix::motorcontrol::can::BaseMotorController::ValueUpdated()'],['../classctre_1_1phoenix_1_1motorcontrol_1_1_i_follower.html#a9a9b5d2f196200e8b41556b91057c567',1,'ctre::phoenix::motorcontrol::IFollower::ValueUpdated()']]],
  ['victorspx',['VictorSPX',['../classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x.html#a54457c3bf53738a7ae2b6571e323d428',1,'ctre::phoenix::motorcontrol::can::VictorSPX::VictorSPX(int deviceNumber)'],['../classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x.html#a2af8e20328c05c0cead13653dd9ca579',1,'ctre::phoenix::motorcontrol::can::VictorSPX::VictorSPX(VictorSPX const &amp;)=delete']]]
];
