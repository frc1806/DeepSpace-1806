var searchData=
[
  ['trajectoryduration',['TrajectoryDuration',['../namespacectre_1_1phoenix_1_1motion.html#a79c598e15e7023fce953d14c4d39a0c0',1,'ctre::phoenix::motion']]]
];
