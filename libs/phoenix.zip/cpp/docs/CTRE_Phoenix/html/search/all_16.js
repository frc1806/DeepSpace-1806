var searchData=
[
  ['valueupdated',['ValueUpdated',['../classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_motor_controller.html#a4712ba671d43070dd7d418504d506d84',1,'ctre::phoenix::motorcontrol::can::BaseMotorController::ValueUpdated()'],['../classctre_1_1phoenix_1_1motorcontrol_1_1_i_follower.html#a9a9b5d2f196200e8b41556b91057c567',1,'ctre::phoenix::motorcontrol::IFollower::ValueUpdated()']]],
  ['velocity',['velocity',['../structctre_1_1phoenix_1_1motion_1_1_trajectory_point.html#ac22c527df12c74f6ba6d073bf99d424a',1,'ctre::phoenix::motion::TrajectoryPoint::velocity()'],['../namespacectre_1_1phoenix_1_1motorcontrol.html#a005f39c5a73e9bd580bd62bcb116520ca88156d46910a2d733443c339a9231d12',1,'ctre::phoenix::motorcontrol::Velocity()']]],
  ['velocitymeasperiod',['VelocityMeasPeriod',['../namespacectre_1_1phoenix_1_1motorcontrol.html#ac7b007d595c8fa57b817fa56f88ee73c',1,'ctre::phoenix::motorcontrol']]],
  ['velocitymeasperiod_2eh',['VelocityMeasPeriod.h',['../_velocity_meas_period_8h.html',1,'']]],
  ['victorspx',['VictorSPX',['../classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x.html',1,'ctre::phoenix::motorcontrol::can::VictorSPX'],['../classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x.html#a54457c3bf53738a7ae2b6571e323d428',1,'ctre::phoenix::motorcontrol::can::VictorSPX::VictorSPX(int deviceNumber)'],['../classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x.html#a2af8e20328c05c0cead13653dd9ca579',1,'ctre::phoenix::motorcontrol::can::VictorSPX::VictorSPX(VictorSPX const &amp;)=delete']]],
  ['victorspx_2ecpp',['VictorSPX.cpp',['../_victor_s_p_x_8cpp.html',1,'']]],
  ['victorspx_2eh',['VictorSPX.h',['../_victor_s_p_x_8h.html',1,'']]]
];
