var searchData=
[
  ['neutraloutput',['NeutralOutput',['../classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_motor_controller.html#a82e272a9acea821ced21eb5ea5d0975d',1,'ctre::phoenix::motorcontrol::can::BaseMotorController::NeutralOutput()'],['../classctre_1_1phoenix_1_1motorcontrol_1_1_i_motor_controller.html#a021f7ba04b8aa271dc2e9c12ef680dfb',1,'ctre::phoenix::motorcontrol::IMotorController::NeutralOutput()']]]
];
