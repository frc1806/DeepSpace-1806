var NAVTREE =
[
  [ "CTRE_Phoenix", "index.html", [
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", "namespacemembers_dup" ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", "namespacemembers_eval" ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_base_motor_controller_8cpp.html",
"_limit_switch_type_8h.html#afd232c45ffd137c1dc94b1efc7697bc9aa88d985e7d457fa3b5ddf31f1e16d353",
"_sensor_term_8h.html#a4f84db28c2d27cd678c7c1e867ba10c5af1431baa9f1b46f10be8b0d8772534e1",
"classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceab3def09f82ae0b229e966df5c2d11a3f",
"classctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_motor_controller.html#a8655a7001e4fdb76605344fdaa5ecb98",
"classctre_1_1phoenix_1_1motorcontrol_1_1lowlevel_1_1_mot_controller___low_level.html#af5be19d8afda34e0f13a43e066d9f1eb",
"com__ctre__phoenix___motor_control___c_a_n___mot_controller_j_n_i_8h.html#aaed3988d3d150781559b1326220dff12",
"namespacemembers_n.html",
"structctre_1_1phoenix_1_1motorcontrol_1_1_sticky_faults.html#a55c1d95b0b99e4a9f3cdd84619e9bded"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';